
package phonenumbervalidatorapp;

import java.util.Scanner;
import java.util.regex.Pattern;


public class PhoneNumberValidator {
    
    private static String numbers;
    public static int option;
    static Scanner console = new Scanner(System.in);
    
    public static boolean phoneNumberConditions(String cs){
        
        return cs.charAt(0) == '2' && cs.charAt(1) == '7' && cs.matches("[0-9]+");
    }
    
    public void phoneNumberInstructions(){
        System.out.println("Enter numbers you want to validate ");
        System.out.println("Don't include '+' because it is already added");
        numbers = console.nextLine();
    }
    public String getNumbers(){
    return numbers;
    }
    
    public void validateNumbers(){
        phoneNumberInstructions();
        
        if(phoneNumberConditions(getNumbers())){
            System.out.println("Your numbers are " + "+"+getNumbers() );
            System.out.println("These are South African phone numbers");
        }
        else{
            System.out.println("Your numbers are " + "+"+getNumbers() );
            System.out.println("These are not South African phone numbers");
        }
        
        
    } 
    
    public void userOptions(){
        System.out.println("Enter the following to select");
        System.out.println(" 1 - to validate domain");
        System.out.println(" 2 - to validate South African numbers");
    }
    
    public static void main(String[] args) {
        PhoneNumberValidator phone = new PhoneNumberValidator();
        DomainValidator domain = new   DomainValidator();

        
        phone.userOptions();
        phone.option = console.nextInt();
        
        if(option == 1){
            domain.validateDomain(); 
        }        
        else if(option == 2){
            
           phone.validateNumbers();
        }
        
       
        
      
        
        
       
        
    }
    
}
