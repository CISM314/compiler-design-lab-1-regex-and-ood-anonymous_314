
package phonenumbervalidatorapp;

import java.util.Scanner;
import java.util.regex.Pattern;


public class DomainValidator {
    protected static String domain;
    
    public static boolean domainConditions(String domain){
        return Pattern.matches("[a-zA-Z]+" + ".co.za", domain);
    }
    
    public static void validateDomain(){
         Scanner console = new Scanner(System.in);
        
         System.out.println("Enter domain you want to validate");
        domain = console.nextLine();
        
        if(domainConditions(domain)){
            System.out.println("Good format");
        }
        
        else{
            System.out.println("bad format");
        }
    }
}
